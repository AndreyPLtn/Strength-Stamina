#include "my_folder.h"

static mf_info_t _folders[MF_MAX_TRACKS] = {0};

int mf_get_count_track() {
	return 0;
}

int mf_get_info(int id, mf_info_t* info) {
	return 0;
}

int mf_add(mf_info_t* mf_info) {
	return 0;
}

int mf_delete(int id) {
	return 0;
}

void mf_reset() {
	return;
}