#include <stdio.h>

#include "my_folder.h"

int main() {
	printf("start app");
}